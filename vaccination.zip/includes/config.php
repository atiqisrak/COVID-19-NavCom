<?php

// Database Constants
define("DB_HOST", "localhost");
define("DB_USER", "navana_admin");
define("DB_PASSWORD", "Navana_Group");
define("DB_NAME", "navana_group");

?>